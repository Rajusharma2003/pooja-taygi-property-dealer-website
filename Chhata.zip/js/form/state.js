// function select_state_func()
// {
// 		var select = document.getElementById("stateid");
//         var typevalue = select.options[select.selectedIndex].value;
// 		//alert(typevalue);
// 		if (typevalue == 'Andaman Nicobar Islands')
// 		{
// 			document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option><option value='Andaman & Nicobar'>Andaman & Nicobar</option></select>";
// 		}
// 		else if (typevalue == 'Andhra Pradesh')
// 		{
// 				document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option><option value='Adilabad'>Adilabad</option>\
// 				<option value='Anantapur'>Anantapur</option>\
// 				<option value='Chittoor'>Chittoor</option>\
// 				<option value='East Godavari'>East Godavari</option>\
// 				<option value='Guntur'>Guntur</option>\
// 				<option value='Hyderabad'>Hyderabad</option>\
// 				<option value='Kadapa'>Kadapa</option>\
// 				<option value='Karimnagar'>Karimnagar</option>\
// 				<option value='Khammam'>Khammam</option>\
// 				<option value='Krishna'>Krishna</option>\
// 				<option value='Kurnool'>Kurnool</option>\
// 				<option value='Mahbubnagar'>Mahbubnagar</option>\
// 				<option value='Medak'>Medak</option>\
// 				<option value='Nalgonda'>Nalgonda</option>\
// 				<option value='Nellore'>Nellore</option>\
// 				<option value='Nizamabad'>Nizamabad</option>\
// 				<option value='Prakasam'>Prakasam</option>\
// 				<option value='Rangareddy'>Rangareddy</option>\
// 				<option value='Srikakulam'>Srikakulam</option>\
// 				<option value='Vishakhapatnam'>Vishakhapatnam</option>\
// 				<option value='Vizianagaram'>Vizianagaram</option>\
// 				<option value='Warangal'>Warangal</option>\
// 				<option value='West Godavari'>West Godavari</option>\
// 				</select>";
			
// 			}
// 		else if (typevalue == 'Arunachal Pradesh')
// 		{
// 		document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option>				<option value='Anjaw'>Anjaw</option>\
// 				<option value='Changlang'>Changlang</option>\
// 				<option value='East Kameng'>East Kameng</option>\
// 				<option value='East Siang'>East Siang</option>\
// 				<option value='Kurung Kumey'>Kurung Kumey</option>\
// 				<option value='Lohit'>Lohit</option>\
// 				<option value='Longding'>Longding</option>\
// 				<option value='Lower Dibang Valley'>Lower Dibang Valley</option>\
// 				<option value='Lower Subansiri'>Lower Subansiri</option>\
// 				<option value='Papum Pare'>Papum Pare</option>\
// 				<option value='Tawang'>Tawang</option>\
// 				<option value='Tirap'>Tirap</option>\
// 				<option value='Upper Dibang Valley'>Upper Dibang Valley</option>\
// 				<option value='Upper Siang'>Upper Siang</option>\
// 				<option value='Upper Subansiri'>Upper Subansiri</option>\
// 				<option value='West Kameng'>West Kameng</option>\
// 				<option value='West Siang'>West Siang</option>\
// 				</select>";
// 		}
// 		else if (typevalue == 'Assam')
// 		{
// 		document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option>				<option value='Baksa'>Baksa</option>\
// 				<option value='Barpeta' >Barpeta</option>\
// 				<option value='Barpeta'>Barpeta</option>\
// 				<option value='Bongaigaon'>Bongaigaon</option>\
// 				<option value='Cachar'>Cachar</option>\
// 				<option value='Chirang'>Chirang</option>\
// 				<option value='Darrang'>Darrang</option>\
// 				<option value='Dhemaji'>Dhemaji</option>\
// 				<option value='Dhubri'>Dhubri</option>\
// 				<option value='Dibrugarh'>Dibrugarh</option>\
// 				<option value='Dima Hasao'>Dima Hasao</option>\
// 				<option value='Goalpara'>Goalpara</option>\
// 				<option value='Golaghat'>Golaghat</option>\
// 				<option value='Hailakandi'>Hailakandi</option>\
// 				<option value='Jorhat'>Jorhat</option>\
// 				<option value='Kamrup Metropolitan'>Kamrup Metropolitan</option>\
// 				<option value='Kamrup'>Kamrup</option>\
// 				<option value='Karbi Anglong'>Karbi Anglong</option>\
// 				<option value='Karimganj'>Karimganj</option>\
// 				<option value='Kokrajhar'>Kokrajhar</option>\
// 				<option value='Lakhimpur'>Lakhimpur</option>\
// 				<option value='Morigaon'>Morigaon</option>\
// 				<option value='Nagaon'>Nagaon</option>\
// 				<option value='Nalbari'>Nalbari</option>\
// 				<option value='Sivasagar'>Sivasagar</option>\
// 				<option value='Sonitpur'>Sonitpur</option>\
// 				<option value='Tinsukia'>Tinsukia</option>\
// 				<option value='Udalguri'>Udalguri</option>\
// 				</select>";
// 		}
// else if (typevalue == 'Bihar')
// 		{
// 		document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option><option value='Araria' >Araria</option>\
// <option value='Arwal'>Arwal</option>\
// <option value='Aurangabad'>Aurangabad</option>\
// <option value='Banka'>Banka</option>\
// <option value='Begusarai'>Begusarai</option>\
// <option value='Bhagalpur'>Bhagalpur</option>\
// <option value='Bhojpur'>Bhojpur</option>\
// <option value='Buxar'>Buxar</option>\
// <option value='Darbhanga'>Darbhanga</option>\
// <option value='East Champaran'>East Champaran</option>\
// <option value='Gaya'>Gaya</option>\
// <option value='Gopalganj'>Gopalganj</option>\
// <option value='Jamui'>Jamui</option>\
// <option value='Jehanabad'>Jehanabad</option>\
// <option value='Kaimur'>Kaimur</option>\
// <option value='Katihar'>Katihar</option>\
// <option value='Khagaria'>Khagaria</option>\
// <option value='Kishanganj'>Kishanganj</option>\
// <option value='Lakhisarai'>Lakhisarai</option>\
// <option value='Madhepura'>Madhepura</option>\
// <option value='Madhubani'>Madhubani</option>\
// <option value='Munger'>Munger</option>\
// <option value='Muzaffarpur'>Muzaffarpur</option>\
// <option value='Nalanda'>Nalanda</option>\
// <option value='Nawada'>Nawada</option>\
// <option value='Patna'>Patna</option>\
// <option value='Purnia'>Purnia</option>\
// <option value='Rohtas'>Rohtas</option>\
// <option value='Saharsa'>Saharsa</option>\
// <option value='Samastipur'>Samastipur</option>\
// <option value='Saran'>Saran</option>\
// <option value='Sheikhpura'>Sheikhpura</option>\
// <option value='Sheohar'>Sheohar</option>\
// <option value='Sitamarhi'>Sitamarhi</option>\
// <option value='Siwan'>Siwan</option>\
// <option value='Supaul'>Supaul</option>\
// <option value='Vaishali'>Vaishali</option>\
// <option value='West Champaran'>West Champaran</option>\
// </select>";
// 		}
// 		/* else if (typevalue == 'Chandigarh')
// 		{
// 		document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option></select>";
// 		} */
// 			else if (typevalue == 'Chhatisgarh')
// 		{
// 		document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option><option value='Balod'>Balod</option>\
// <option value='Baloda Bazar'>Baloda Bazar</option>\
// <option value='Balrampur'>Balrampur</option>\
// <option value='Bastar'>Bastar</option>\
// <option value='Bemetara'>Bemetara</option>\
// <option value='Bijapur'>Bijapur</option>\
// <option value='Bilaspur'>Bilaspur</option>\
// <option value='Dantewada'>Dantewada</option>\
// <option value='Dhamtari'>Dhamtari</option>\
// <option value='Durg'>Durg</option>\
// <option value='Gariaband'>Gariaband</option>\
// <option value='Janjgir-Champa'>Janjgir-Champa</option>\
// <option value='Jashpur'>Jashpur</option>\
// <option value='Kabirdham'>Kabirdham</option>\
// <option value='Kanker'>Kanker</option>\
// <option value='Kondagaon'>Kondagaon</option>\
// <option value='Korba'>Korba</option>\
// <option value='Koriya'>Koriya</option>\
// <option value='Mahasamund'>Mahasamund</option>\
// <option value='Mungeli'>Mungeli</option>\
// <option value='Narayanpur'>Narayanpur</option>\
// <option value='Raigarh'>Raigarh</option>\
// <option value='Raipur'>Raipur</option>\
// <option value='Rajnandgaon'>Rajnandgaon</option>\
// <option value='Sukma'>Sukma</option>\
// <option value='Surajpur'>Surajpur</option>\
// <option value='Surguja'>Surguja</option>\
// </select>";
// 		}
// else if (typevalue == 'Delhi')
// 		{
// 		document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option>		<option value='Central 11'>Central 11</option>\
// <option value='East 11'>East 11</option>\
// <option value='New 11'>New 11</option>\
// <option value='North 11'>North 11</option>\
// <option value='North East'>North East</option>\
// <option value='North West 11'>North West 11</option>\
// <option value='South 11'>South 11</option>\
// <option value='South West 11'>South West 11</option>\
// <option value='West 11'>West 11</option>\
// </select>";
// 		}
// 		else if (typevalue == 'Goa')
// 		{
// 		document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option><option value='North 12' >North 12</option>\
// <option value='South 12' >South 12</option>\
// </select>";
// 		}
// 		else if (typevalue == 'Gujarat')
// 		{
// 		document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option><option value='Ahmedabad'>Ahmedabad</option>\
// <option value='Amreli District'>Amreli District</option>\
// <option value='Anand'>Anand</option>\
// <option value='Banaskantha'>Banaskantha</option>\
// <option value='Bharuch'>Bharuch</option>\
// <option value='Bhavnagar'>Bhavnagar</option>\
// <option value='Dahod'>Dahod</option>\
// <option value='Dang'>Dang</option>\
// <option value='Gandhinagar'>Gandhinagar</option>\
// <option value='Jamnagar'>Jamnagar</option>\
// <option value='Junagadh'>Junagadh</option>\
// <option value='Kheda'>Kheda</option>\
// <option value='Kutch'>Kutch</option>\
// <option value='Mehsana'>Mehsana</option>\
// <option value='Narmada'>Narmada</option>\
// <option value='Navsari'>Navsari</option>\
// <option value='Panchmahal'>Panchmahal</option>\
// <option value='Patan'>Patan</option>\
// <option value='Porbandar'>Porbandar</option>\
// <option value='Rajkot'>Rajkot</option>\
// <option value='Sabarkantha'>Sabarkantha</option>\
// <option value='Surat'>Surat</option>\
// <option value='Surendranagar'>Surendranagar</option>\
// <option value='Tapi'>Tapi</option>\
// <option value='Vadodara'>Vadodara</option>\
// <option value='Valsad'>Valsad</option>\
// </select>";
// 		}
// 		else if (typevalue == 'Haryana')
// 		{
// 			document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option><option value='Ambala'>Ambala</option>\
// <option value='Bhiwani'>Bhiwani</option>\
// <option value='Faridabad'>Faridabad</option>\
// <option value='Fatehabad'>Fatehabad</option>\
// <option value='Gurgaon'>Gurgaon</option>\
// <option value='Hisar'>Hisar</option>\
// <option value='Jhajjar'>Jhajjar</option>\
// <option value='Jind'>Jind</option>\
// <option value='Kaithal'>Kaithal</option>\
// <option value='Karnal'>Karnal</option>\
// <option value='Kurukshetra'>Kurukshetra</option>\
// <option value='Mahendragarh'>Mahendragarh</option>\
// <option value='Mewat'>Mewat</option>\
// <option value='Palwal'>Palwal</option>\
// <option value='Panchkula'>Panchkula</option>\
// <option value='Panipat'>Panipat</option>\
// <option value='Rewari'>Rewari</option>\
// <option value='Rohtak'>Rohtak</option>\
// <option value='Sirsa'>Sirsa</option>\
// <option value='Sonipat'>Sonipat</option>\
// <option value='Yamuna Nagar'>Yamuna Nagar</option>\
// </select>";
// 		}
// 		else if (typevalue == 'Himachal Pradesh')
// 		{
// 		document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option><option value='Bilaspur'>Bilaspur</option>\
// <option value='Chamba'>Chamba</option>\
// <option value='Hamirpur'>Hamirpur</option>\
// <option value='Kangra'>Kangra</option>\
// <option value='Kinnaur'>Kinnaur</option>\
// <option value='Kullu'>Kullu</option>\
// <option value='Lahaul and Spiti'>Lahaul and Spiti</option>\
// <option value='Mandi'>Mandi</option>\
// <option value='Shimla'>Shimla</option>\
// <option value='Sirmaur'>Sirmaur</option>\
// <option value='Solan'>Solan</option>\
// <option value='Una'>Una</option>\
// </select>";
// 		}
// 		else if (typevalue == 'Jammu and Kashmir')
// 		{
// 			document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option>			<option value='Kathua District'>Kathua District</option>\
// <option value='Anantnag District'>Anantnag District</option>\
// <option value='Bandipora District'>Bandipora District</option>\
// <option value='Baramulla District'>Baramulla District</option>\
// <option value='Budgam District'>Budgam District</option>\
// <option value='Doda District'>Doda District</option>\
// <option value='Ganderbal District'>Ganderbal District</option>\
// <option value='Jammu District'>Jammu District</option>\
// <option value='Kargil District'>Kargil District</option>\
// <option value='Kishtwar District'>Kishtwar District</option>\
// <option value='Kulgam District'>Kulgam District</option>\
// <option value='Kupwara District'>Kupwara District</option>\
// <option value='Leh District'>Leh District</option>\
// <option value='Poonch District'>Poonch District</option>\
// <option value='Pulwama District'>Pulwama District</option>\
// <option value='Rajouri District'>Rajouri District</option>\
// <option value='Ramban District'>Ramban District</option>\
// <option value='Reasi District'>Reasi District</option>\
// <option value='Samba District'>Samba District</option>\
// <option value='Shopian District'>Shopian District</option>\
// <option value='Srinagar District'>Srinagar District</option>\
// <option value='Udhampur District'>Udhampur District</option>\
// </select>";
// 		}
// 		else if (typevalue == 'Jharkhand')
// 		{
// 				document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option><option value='Bokaro'>Bokaro</option>\
// <option value='Chatra'>Chatra</option>\
// <option value='Deoghar'>Deoghar</option>\
// <option value='Dhanbad'>Dhanbad</option>\
// <option value='Dumka'>Dumka</option>\
// <option value='Garhwa'>Garhwa</option>\
// <option value='Giridih'>Giridih</option>\
// <option value='Godda'>Godda</option>\
// <option value='Gumla'>Gumla</option>\
// <option value='Hazaribagh'>Hazaribagh</option>\
// <option value='Jamtara'>Jamtara</option>\
// <option value='Khunti'>Khunti</option>\
// <option value='Kodarma'>Kodarma</option>\
// <option value='Latehar'>Latehar</option>\
// <option value='Lohardaga'>Lohardaga</option>\
// <option value='Pakur'>Pakur</option>\
// <option value='Palamu'>Palamu</option>\
// <option value='Pashchimi Singhbhum'>Pashchimi Singhbhum</option>\
// <option value='Purbi Singhbhum'>Purbi Singhbhum</option>\
// <option value='Ramgarh'>Ramgarh</option>\
// <option value='Ranchi'>Ranchi</option>\
// <option value='Sahibganj'>Sahibganj</option>\
// <option value='Saraikela Kharsawan'>Saraikela Kharsawan</option>\
// <option value='Simdega'>Simdega</option>\
// </select>";
// 		}
// 		else if (typevalue == 'Karnataka')
// 		{
// 				document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option><option value='Bagalkot'>Bagalkot</option>\
// <option value='Bangalore Rural'>Bangalore Rural</option>\
// <option value='Bangalore Urban'>Bangalore Urban</option>\
// <option value='Belgaum'>Belgaum</option>\
// <option value='Bellary'>Bellary</option>\
// <option value='Bidar'>Bidar</option>\
// <option value='Bijapur'>Bijapur</option>\
// <option value='Chamarajanagar'>Chamarajanagar</option>\
// <option value='Chikballapur'>Chikballapur</option>\
// <option value='Chikmagalur'>Chikmagalur</option>\
// <option value='Chitradurga'>Chitradurga</option>\
// <option value='Dakshina Kannada'>Dakshina Kannada</option>\
// <option value='Davanagere'>Davanagere</option>\
// <option value='Dharwad'>Dharwad</option>\
// <option value='Gadag'>Gadag</option>\
// <option value='Gulbarga'>Gulbarga</option>\
// <option value='Hassan'>Hassan</option>\
// <option value='Haveri'>Haveri</option>\
// <option value='Kodagu'>Kodagu</option>\
// <option value='Kolar'>Kolar</option>\
// <option value='Koppal'>Koppal</option>\
// <option value='Mandya'>Mandya</option>\
// <option value='Mysore'>Mysore</option>\
// <option value='Raichur'>Raichur</option>\
// <option value='Ramanagara'>Ramanagara</option>\
// <option value='Shimoga'>Shimoga</option>\
// <option value='Tumakuru'>Tumakuru</option>\
// <option value='Udupi'>Udupi</option>\
// <option value='Uttara Kannada'>Uttara Kannada</option>\
// <option value='Yadgir'>Yadgir</option>\
// </select>";
// 		}
// 		else if (typevalue == 'Kerala')
// 		{
// 		document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option><option value='Alappuzha'>Alappuzha</option>\
// <option value='Ernakulam'>Ernakulam</option>\
// <option value='Idukki'>Idukki</option>\
// <option value='Kannur'>Kannur</option>\
// <option value='Kasaragod'>Kasaragod</option>\
// <option value='Kollam'>Kollam</option>\
// <option value='Kottayam'>Kottayam</option>\
// <option value='Kozhikode'>Kozhikode</option>\
// <option value='Malappuram'>Malappuram</option>\
// <option value='Palakkad'>Palakkad</option>\
// <option value='Pathanamthitta'>Pathanamthitta</option>\
// <option value='Thiruvananthapuram'>Thiruvananthapuram</option>\
// <option value='Thrissur'>Thrissur</option>\
// <option value='Wayanad'>Wayanad</option>\
// </select>";
// 		}
// 		else if (typevalue == 'Madhya Pradesh')
// 		{
// 		document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option>\
// 		<option value='Alirajpur'>Alirajpur</option>\
// <option value='Anuppur'>Anuppur</option>\
// <option value='Ashoknagar'>Ashoknagar</option>\
// <option value='Balaghat'>Balaghat</option>\
// <option value='Barwani'>Barwani</option>\
// <option value='Betul'>Betul</option>\
// <option value='Bhind'>Bhind</option>\
// <option value='Bhopal'>Bhopal</option>\
// <option value='Bhurhanpur'>Bhurhanpur</option>\
// <option value='Chhatarpur'>Chhatarpur</option>\
// <option value='Chhindwara'>Chhindwara</option>\
// <option value='Damoh'>Damoh</option>\
// <option value='Datia'>Datia</option>\
// <option value='Dewas'>Dewas</option>\
// <option value='Dhar'>Dhar</option>\
// <option value='Dindori'>Dindori</option>\
// <option value='Guna'>Guna</option>\
// <option value='Gwalior'>Gwalior</option>\
// <option value='Harda'>Harda</option>\
// <option value='Hoshangabad'>Hoshangabad</option>\
// <option value='Indore'>Indore</option>\
// <option value='Jabalpur'>Jabalpur</option>\
// <option value='Jhabua'>Jhabua</option>\
// <option value='Katni'>Katni</option>\
// <option value='Khandwa (East Nimari)'>Khandwa (East Nimari)</option>\
// <option value='Khargone (West Nimari)'>Khargone (West Nimari)</option>\
// <option value='Mandla'>Mandla</option>\
// <option value='Mandsaur'>Mandsaur</option>\
// <option value='Morena'>Morena</option>\
// <option value='Narsimhapur'>Narsimhapur</option>\
// <option value='Neemuch'>Neemuch</option>\
// <option value='Panna'>Panna</option>\
// <option value='Raisen'>Raisen</option>\
// <option value='Rajgarh'>Rajgarh</option>\
// <option value='Ratlam'>Ratlam</option>\
// <option value='Rewa'>Rewa</option>\
// <option value='Sagar'>Sagar</option>\
// <option value='Satna'>Satna</option>\
// <option value='Sehore'>Sehore</option>\
// <option value='Seoni'>Seoni</option>\
// <option value='Shahdol'>Shahdol</option>\
// <option value='Shajapur'>Shajapur</option>\
// <option value='Sheopur'>Sheopur</option>\
// <option value='Shivpuri'>Shivpuri</option>\
// <option value='Sidhi'>Sidhi</option>\
// <option value='Singrauli'>Singrauli</option>\
// <option value='Tikamgarh'>Tikamgarh</option>\
// <option value='Ujjain'>Ujjain</option>\
// <option value='Umaria'>Umaria</option>\
// <option value='Vidisha'>Vidisha</option>\
// </select>";
// 		}
// 		else if (typevalue == 'Maharashtra')
// 		{
// 		document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option><option value='Ahmednagar'>Ahmednagar</option>\
// <option value='Akola'>Akola</option>\
// <option value='Amravati'>Amravati</option>\
// <option value='Aurangabad'>Aurangabad</option>\
// <option value='Beed'>Beed</option>\
// <option value='Bhandara'>Bhandara</option>\
// <option value='Buldana'>Buldana</option>\
// <option value='Chandrapur'>Chandrapur</option>\
// <option value='Dhule'>Dhule</option>\
// <option value='Gadchiroli'>Gadchiroli</option>\
// <option value='Gondia'>Gondia</option>\
// <option value='Hingoli'>Hingoli</option>\
// <option value='Jalgaon'>Jalgaon</option>\
// <option value='Jalna'>Jalna</option>\
// <option value='Kolhapur'>Kolhapur</option>\
// <option value='Latur'>Latur</option>\
// <option value='Mumbai City'>Mumbai City</option>\
// <option value='Mumbai Suburban'>Mumbai Suburban</option>\
// <option value='Nagpur'>Nagpur</option>\
// <option value='Nanded'>Nanded</option>\
// <option value='Nandurbar'>Nandurbar</option>\
// <option value='Nashik'>Nashik</option>\
// <option value='Osmanabad'>Osmanabad</option>\
// <option value='Parbhani'>Parbhani</option>\
// <option value='Pune'>Pune</option>\
// <option value='Raigarh'>Raigarh</option>\
// <option value='Ratnagiri'>Ratnagiri</option>\
// <option value='Sangli'>Sangli</option>\
// <option value='Satara'>Satara</option>\
// <option value='Sindhudurg'>Sindhudurg</option>\
// <option value='Solapur'>Solapur</option>\
// <option value='Thane'>Thane</option>\
// <option value='Wardha'>Wardha</option>\
// <option value='Washim'>Washim</option>\
// <option value='Yavatmal'>Yavatmal</option>\
// </select>";
// 		}
// 		else if (typevalue == 'Manipur')
// 		{
// 		document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option>\
// 		<option value='Bishnupur'>Bishnupur</option>\
// <option value='Chandel'>Chandel</option>\
// <option value='Churachandpur'>Churachandpur</option>\
// <option value='Imphal East'>Imphal East</option>\
// <option value='Imphal West'>Imphal West</option>\
// <option value='Senapati'>Senapati</option>\
// <option value='Tamenglong'>Tamenglong</option>\
// <option value='Thoubal'>Thoubal</option>\
// <option value='Ukhrul'>Ukhrul</option>\
// </select>";
// 		}
// 			else if (typevalue == 'Meghalaya')
// 		{
// 		document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option>\
// 		<option value='Baghmara'>Baghmara</option>\
// <option value='Jowai/Khliehriat'>Jowai/Khliehriat</option>\
// <option value='Nongpoh'>Nongpoh</option>\
// <option value='Nongstoin/Mawkyrwat'>Nongstoin/Mawkyrwat</option>\
// <option value='Shillong'>Shillong</option>\
// <option value='Tura/Ampati'>Tura/Ampati</option>\
// <option value='Williamnagar/Resubelpara'>Williamnagar/Resubelpara</option>\
// </select>";
// 		}
// 		else if (typevalue == 'Mizoram')
// 		{
// 		document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option>\
// 		<option value='Aizawl'>Aizawl</option>\
// <option value='Champhai'>Champhai</option>\
// <option value='Kolasib'>Kolasib</option>\
// <option value='Lawngtlai'>Lawngtlai</option>\
// <option value='Lunglei'>Lunglei</option>\
// <option value='Mamit'>Mamit</option>\
// <option value='Saiha'>Saiha</option>\
// <option value='Serchhip'>Serchhip</option>\
// </select>";
// 		}
// 		else if (typevalue == 'Nagaland')
// 		{
// 		document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option>\
// 		<option value='Dimapur'>Dimapur</option>\
// <option value='Kiphire'>Kiphire</option>\
// <option value='Kohima'>Kohima</option>\
// <option value='Longleng'>Longleng</option>\
// <option value='Mokokchung'>Mokokchung</option>\
// <option value='Mon'>Mon</option>\
// <option value='Piren'>Piren</option>\
// <option value='Phek'>Phek</option>\
// <option value='Tuensang'>Tuensang</option>\
// <option value='Wokha'>Wokha</option>\
// <option value='Zunheboto'>Zunheboto</option>\
// </select>";
// 		}
// 		else if (typevalue == 'Orissa')
// 		{
// 		document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option><option value='Angul (Anugul)'>Angul (Anugul)</option>\
// <option value='Baleswar (Balasore)'>Baleswar (Balasore)</option>\
// <option value='Bargarh (Baragarh)'>Bargarh (Baragarh)</option>\
// <option value='Bhadrak'>Bhadrak</option>\
// <option value='Bolangir (Balangir)'>Bolangir (Balangir)</option>\
// <option value='Boudh (Bauda)'>Boudh (Bauda)</option>\
// <option value='Cuttack'>Cuttack</option>\
// <option value='Debagarh (Deogarh)'>Debagarh (Deogarh)</option>\
// <option value='Dhenkanal'>Dhenkanal</option>\
// <option value='Gajapati'>Gajapati</option>\
// <option value='Ganjam'>Ganjam</option>\
// <option value='Jagatsinghpur'>Jagatsinghpur</option>\
// <option value='Jajapur (Jajpur)'>Jajapur (Jajpur)</option>\
// <option value='Jharsuguda'>Jharsuguda</option>\
// <option value='Kalahandi'>Kalahandi</option>\
// <option value='Kandhamal'>Kandhamal</option>\
// <option value='Kendrapara'>Kendrapara</option>\
// <option value='Kendujhar (Keonjhar)'>Kendujhar (Keonjhar)</option>\
// <option value='Khordha'>Khordha</option>\
// <option value='Koraput'>Koraput</option>\
// <option value='Malkangiri'>Malkangiri</option>\
// <option value='Mayurbhanj'>Mayurbhanj</option>\
// <option value='Nabarangpur'>Nabarangpur</option>\
// <option value='Nayagarh'>Nayagarh</option>\
// <option value='Nuapada'>Nuapada</option>\
// <option value='Puri'>Puri</option>\
// <option value='Rayagada'>Rayagada</option>\
// <option value='Sambalpur'>Sambalpur</option>\
// <option value='Subarnapur (Sonepur)'>Subarnapur (Sonepur)</option>\
// <option value='Sundargarh (Sundergarh)'>Sundargarh (Sundergarh)</option>\
// </select>";
// 		}
// 		else if (typevalue == '24')
// 		{
// 		document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option><option value='Pondicherry' >Pondicherry</option></select>";
// 		}
// 		else if (typevalue == 'Punjab')
// 		{
// 		document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option><option value='Amritsar'>Amritsar</option>\
// <option value='Barnala'>Barnala</option>\
// <option value='Bathinda'>Bathinda</option>\
// <option value='Faridkot'>Faridkot</option>\
// <option value='Fatehgarh Sahib'>Fatehgarh Sahib</option>\
// <option value='Fazilika'>Fazilika</option>\
// <option value='Firozpur'>Firozpur</option>\
// <option value='Gurdaspur'>Gurdaspur</option>\
// <option value='Hoshiarpur'>Hoshiarpur</option>\
// <option value='Jalandhar'>Jalandhar</option>\
// <option value='Kapurthala'>Kapurthala</option>\
// <option value='Ludhiana'>Ludhiana</option>\
// <option value='Mansa'>Mansa</option>\
// <option value='Moga'>Moga</option>\
// <option value='Mohali'>Mohali</option>\
// <option value='Muktasar'>Muktasar</option>\
// <option value='Pathankot'>Pathankot</option>\
// <option value='Patiala'>Patiala</option>\
// <option value='Rupnagar'>Rupnagar</option>\
// <option value='Sangrur'>Sangrur</option>\
// <option value='Shahid Bhagat Singh Nagar'>Shahid Bhagat Singh Nagar</option>\
// <option value='Tarn Taran'>Tarn Taran</option>\
// </select>";
// 		}else if (typevalue == 'Rajasthan')
// 		{
// 		document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option><option value='Ajmer'>Ajmer</option>\
// <option value='Alwar'>Alwar</option>\
// <option value='Banswara'>Banswara</option>\
// <option value='Baran'>Baran</option>\
// <option value='Barmer'>Barmer</option>\
// <option value='Bharatpur'>Bharatpur</option>\
// <option value='Bhilwara'>Bhilwara</option>\
// <option value='Bikaner'>Bikaner</option>\
// <option value='Bundi'>Bundi</option>\
// <option value='Chittorgarh'>Chittorgarh</option>\
// <option value='Churu'>Churu</option>\
// <option value='Dausa'>Dausa</option>\
// <option value='Dholpur'>Dholpur</option>\
// <option value='Dungarpur'>Dungarpur</option>\
// <option value='Hanumangarh'>Hanumangarh</option>\
// <option value='Jaipur'>Jaipur</option>\
// <option value='Jaisalmer'>Jaisalmer</option>\
// <option value='Jalor'>Jalor</option>\
// <option value='Jhalawar'>Jhalawar</option>\
// <option value='Jhunjhunu'>Jhunjhunu</option>\
// <option value='Jodhpur'>Jodhpur</option>\
// <option value='Karauli'>Karauli</option>\
// <option value='Kota'>Kota</option>\
// <option value='Nagaur'>Nagaur</option>\
// <option value='Pali'>Pali</option>\
// <option value='Pratapgarh'>Pratapgarh</option>\
// <option value='Rajsamand'>Rajsamand</option>\
// <option value='Sawai Madhopur'>Sawai Madhopur</option>\
// <option value='Sikar'>Sikar</option>\
// <option value='Sirohi'>Sirohi</option>\
// <option value='Sri Ganganagar'>Sri Ganganagar</option>\
// <option value='Tonk'>Tonk</option>\
// <option value='Udaipur'>Udaipur</option>\
// </select>";
// 		}
// else if (typevalue == 'Tamil Nadu')
// 		{
// 		document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option><option value='Alandur' >Alandur</option>\
// <option value='Ariyalur'>Ariyalur</option>\
// <option value='Chennai'>Chennai</option>\
// <option value='Coimbatore'>Coimbatore</option>\
// <option value='Cuddalore'>Cuddalore</option>\
// <option value='Dharmapuri'>Dharmapuri</option>\
// <option value='Dindigul'>Dindigul</option>\
// <option value='Erode'>Erode</option>\
// <option value='Kanchipuram'>Kanchipuram</option>\
// <option value='Kanniyakumari'>Kanniyakumari</option>\
// <option value='Karur'>Karur</option>\
// <option value='Krishnagiri'>Krishnagiri</option>\
// <option value='Madurai'>Madurai</option>\
// <option value='Nagapattinam'>Nagapattinam</option>\
// <option value='Namakkal'>Namakkal</option>\
// <option value='Nilgiris'>Nilgiris</option>\
// <option value='Perambular'>Perambular</option>\
// <option value='Pudukkottai'>Pudukkottai</option>\
// <option value='Ramnathapuram'>Ramnathapuram</option>\
// <option value='Salem'>Salem</option>\
// <option value='Sivaganga'>Sivaganga</option>\
// <option value='Thanjavur'>Thanjavur</option>\
// <option value='Theni District'>Theni District</option>\
// <option value='Thoothukodi District'>Thoothukodi District</option>\
// <option value='Tiruchirappalli'>Tiruchirappalli</option>\
// <option value='Tirunelveli'>Tirunelveli</option>\
// <option value='Tiruppur'>Tiruppur</option>\
// <option value='Tiruvallur'>Tiruvallur</option>\
// <option value='Tiruvannamalai'>Tiruvannamalai</option>\
// <option value='Tiruvarur'>Tiruvarur</option>\
// <option value='Vellore'>Vellore</option>\
// <option value='Villupuram'>Villupuram</option>\
// <option value='Virudhnagar'>Virudhnagar</option>\
// </select>";
// 		}
// 		else if (typevalue == 'Tripura')
// 		{
// 		document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option>\
// 		<option value='Dhalai'>Dhalai</option>\
// <option value='Gomati'>Gomati</option>\
// <option value='Khowai'>Khowai</option>\
// <option value='North Tripura'>North Tripura</option>\
// <option value='Sipahijala'>Sipahijala</option>\
// <option value='South Tripura'>South Tripura</option>\
// <option value='Unakoti'>Unakoti</option>\
// <option value='West Tripura'>West Tripura</option>\
// <option value='Tripura'>Tripura</option>\
// 		</select>";
// 		}
// 	else if (typevalue == 'Uttar Pradesh')
// 		{
// 		document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option><option value='Agra'>Agra</option>\
// <option value='Aligarh'>Aligarh</option>\
// <option value='Allahabad'>Allahabad</option>\
// <option value='Ambedkar Nagar'>Ambedkar Nagar</option>\
// <option value='Amethi'>Amethi</option>\
// <option value='Auraiya'>Auraiya</option>\
// <option value='Azamgarh'>Azamgarh</option>\
// <option value='Baghpat'>Baghpat</option>\
// <option value='Bahraich'>Bahraich</option>\
// <option value='Ballia'>Ballia</option>\
// <option value='Balrampur'>Balrampur</option>\
// <option value='Banda'>Banda</option>\
// <option value='Bara Banki'>Bara Banki</option>\
// <option value='Bareilly'>Bareilly</option>\
// <option value='Basti'>Basti</option>\
// <option value='Bijnor'>Bijnor</option>\
// <option value='Budaun'>Budaun</option>\
// <option value='Bulandshahr'>Bulandshahr</option>\
// <option value='Chandauli'>Chandauli</option>\
// <option value='Chitrakoot'>Chitrakoot</option>\
// <option value='Deoria'>Deoria</option>\
// <option value='Etah'>Etah</option>\
// <option value='Etawah'>Etawah</option>\
// <option value='Faizabad'>Faizabad</option>\
// <option value='Farrukhabad'>Farrukhabad</option>\
// <option value='Fatehpur'>Fatehpur</option>\
// <option value='Firozabad'>Firozabad</option>\
// <option value='Gautam Buddha Nagar'>Gautam Buddha Nagar</option>\
// <option value='Ghaziabad'>Ghaziabad</option>\
// <option value='Ghazipur'>Ghazipur</option>\
// <option value='Gonda'>Gonda</option>\
// <option value='Gorakhpur'>Gorakhpur</option>\
// <option value='Hamirpur'>Hamirpur</option>\
// <option value='Hapur'>Hapur</option>\
// <option value='Hardoi'>Hardoi</option>\
// <option value='Jalaun'>Jalaun</option>\
// <option value='Jaunpur'>Jaunpur</option>\
// <option value='Jhansi'>Jhansi</option>\
// <option value='Jyotiba Phule Nagar'>Jyotiba Phule Nagar</option>\
// <option value='Kannauj'>Kannauj</option>\
// <option value='Kanpur Dehat'>Kanpur Dehat</option>\
// <option value='Kanpur Nagar'>Kanpur Nagar</option>\
// <option value='Kasganj'>Kasganj</option>\
// <option value='Kaushambi'>Kaushambi</option>\
// <option value='Kushinagar'>Kushinagar</option>\
// <option value='Lakhimpur-Kheri'>Lakhimpur-Kheri</option>\
// <option value='Lalitpur'>Lalitpur</option>\
// <option value='Lucknow'>Lucknow</option>\
// <option value='Hathras'>Hathras</option>\
// <option value='Mahoba'>Mahoba</option>\
// <option value='Mahrajganj'>Mahrajganj</option>\
// <option value='Mainpuri'>Mainpuri</option>\
// <option value='Mathura'>Mathura</option>\
// <option value='Mau'>Mau</option>\
// <option value='Meerut'>Meerut</option>\
// <option value='Mirzapur'>Mirzapur</option>\
// <option value='Moradabad'>Moradabad</option>\
// <option value='Muzaffarnagar'>Muzaffarnagar</option>\
// <option value='Pilibhit'>Pilibhit</option>\
// <option value='Pratapgarh'>Pratapgarh</option>\
// <option value='Rae Bareli'>Rae Bareli</option>\
// <option value='Rampur'>Rampur</option>\
// <option value='Saharanpur'>Saharanpur</option>\
// <option value='Sambhal'>Sambhal</option>\
// <option value='Sant Kabir Nagar'>Sant Kabir Nagar</option>\
// <option value='Sant Ravidas Nagar (Bhadohi)'>Sant Ravidas Nagar (Bhadohi)</option>\
// <option value='Shahjahanpur'>Shahjahanpur</option>\
// <option value='shamli'>shamli</option>\
// <option value='Shrawasti'>Shrawasti</option>\
// <option value='Siddharthnagar'>Siddharthnagar</option>\
// <option value='Sitapur'>Sitapur</option>\
// <option value='Sonbhadra'>Sonbhadra</option>\
// <option value='Sultanpur'>Sultanpur</option>\
// <option value='Unnao'>Unnao</option>\
// <option value='Varanasi'>Varanasi</option>\
// </select>";
// 		}
// 		else if (typevalue == 'Uttaranchal')
// 		{
// 		document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option><option value='Almora'>Almora</option>\
// <option value='Bageshwar'>Bageshwar</option>\
// <option value='Chamoli'>Chamoli</option>\
// <option value='Champawat'>Champawat</option>\
// <option value='Dehradun'>Dehradun</option>\
// <option value='Haridwar'>Haridwar</option>\
// <option value='Nainital'>Nainital</option>\
// <option value='Pauri Garhwal'>Pauri Garhwal</option>\
// <option value='Pithoragarh'>Pithoragarh</option>\
// <option value='Rudra Prayag'>Rudra Prayag</option>\
// <option value='Tehri Garhwal'>Tehri Garhwal</option>\
// <option value='Udham Singh Nagar'>Udham Singh Nagar</option>\
// <option value='Uttarkashi'>Uttarkashi</option>\
// </select>";
// 		}
// 		else if (typevalue == 'West Bengal')
// 		{
// 		document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option><option value='Bankura'>Bankura</option>\
// <option value='Bardhaman'>Bardhaman</option>\
// <option value='Birbhum'>Birbhum</option>\
// <option value='Cooch Behar'>Cooch Behar</option>\
// <option value='Darjeeling'>Darjeeling</option>\
// <option value='East Midnapore'>East Midnapore</option>\
// <option value='Hooghly'>Hooghly</option>\
// <option value='Howrah'>Howrah</option>\
// <option value='Jalpaiguri'>Jalpaiguri</option>\
// <option value='Kolkata'>Kolkata</option>\
// <option value='Malda'>Malda</option>\
// <option value='Murshidabad'>Murshidabad</option>\
// <option value='Nadia'>Nadia</option>\
// <option value='North 24 Parganas'>North 24 Parganas</option>\
// <option value='North Dinajpur'>North Dinajpur</option>\
// <option value='Purulia'>Purulia</option>\
// <option value='South 24 Parganas'>South 24 Parganas</option>\
// <option value='South Dinajpur'>South Dinajpur</option>\
// <option value='West Midnapore'>West Midnapore</option>\
// </select>";
// 		}
// 	else if (typevalue == 'Dadra Nagar Haveli')
// 		{

// 		document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option><option value='Dadra & Nagar Haveli'>Dadra & Nagar Haveli</option>\
// </select>";
// 		}
// 	else if (typevalue == 'Daman Diu')
// 		{
// 		document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option><option value='Daman & Diu'>Daman & Diu</option>\
// </select>";
// 		}
// 		else if (typevalue == 'Sikkim')
// 		{
// 		document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option>\
// 			<option value='East Sikkim'>East Sikkim</option>\
// <option value='North Sikkim'>North Sikkim</option>\
// <option value='South Sikkim'>South Sikkim</option>\
// <option value='West Sikkim'>West Sikkim</option>\
// </select>";
// 		}
// 		else if (typevalue == 36)
// 		{
// 		document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option>\
// 			<option value='Adilabad' >Adilabad</option>\
// <option value='Hyderabad' >Hyderabad</option>\
// <option value='Jagtial' >Jagtial</option>\
// <option value='Jogulamba' >Jogulamba</option>\
// <option value='Karimnagar' >Karimnagar</option>\
// <option value='Khammam' >Khammam</option>\
// <option value='Komaram Bheem' >Komaram Bheem</option>\
// <option value='Medak' >Medak</option>\
// <option value='Nagarkurnool' >Nagarkurnool</option>\
// <option value='Nalgonda' >Nalgonda</option>\
// <option value='Nizamabad' >Nizamabad</option>\
// <option value='Wanaparthy' >Wanaparthy</option></select>";

// 		}
		
			
// 		else if(typevalue == 'Biratnagar')
// 		{
// 	   document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option>\
// 		<option value='Dhankuta' >Dhankuta</option>\
//         <option value='Ilam' >Ilam</option>\
//         <option value='Diktel' >Diktel</option>\
//         <option value='Siddhicharan'>Siddhicharan</option>\
//         <option value='Phidim' >Phidim</option>\
//         <option value='Khandbari'>Khandbari</option>\
//         <option value='Salleri'>Salleri</option>\
//        <option value='Inaruwa'>Inaruwa</option>\
//        <option value='Taplejung'>Taplejung</option>\
//        <option value='Myanglung'>Myanglung</option>\
//        <option value='Gaighat'>Gaighat</option>\
// 	   </select>";

			
// 		}
		
		
// 				else if(typevalue == 'Janakpur')
// 		{
// 	   document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option>\
// 		<option value='Rajbiraj'>Rajbiraj</option>\
//         <option value='Siraha'>Siraha</option>\
//         <option value='Janakpur'>Janakpur</option>\
//         <option value='Jaleshwar'>Jaleshwar</option>\
//         <option value='Malangwa'>Malangwa</option>\
//         <option value='Kalaiya' >Kalaiya</option>\
//         <option value='Birganj'>Birganj</option>\
//         <option value='Gaur'>Gaur</option>\
// 		</select>";
       

			
// 		}
		
// 			else if(typevalue == 'Hetauda')
// 		{
// 	   document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option>\
// 		<option value='Manthali'>Manthali</option>\
//         <option value='Bhimeshwar'>Bhimeshwar</option>\
//         <option value='Bhaktapur'>Bhaktapur</option>\
//         <option value='Nilkantha'>Nilkantha</option>\
//         <option value='Kathmandu'>Kathmandu</option>\
//         <option value='Dhulikhel' >Dhulikhel</option>\
//         <option value='Dhunche'>Dhunche</option>\
//         <option value='Chautara'>Chautara</option>\
//        </select>";

			
// 		}
// 			else if(typevalue == 'Pokhara')
// 		{
// 	   document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option>\
// 		<option value='Baglung'>Baglung</option>\
//         <option value='Gorkha'>Gorkha</option>\
//         <option value='Pokhara'>Pokhara</option>\
//         <option value='Besisahar'>Besisahar</option>\
//         <option value='Chame'>Chame</option>\
//         <option value='Jomsom' >Jomsom</option>\
//         <option value='Beni'>Beni</option>\
//         <option value='Kawasoti'>Kawasoti</option>\
//        <option value='Kusma'>Kusma	</option>\
//        <option value='Putalibazar'>Putalibazar	</option>\
//        <option value='Damauli'>Damauli	</option>\
// 	   </select>";
       

			
// 		}
		
		
// 			else if(typevalue == 'Butwal')
// 		{
// 	   document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option>\
// 		<option value='Taulihawa'>Taulihawa</option>\
//         <option value='Ramgram'>Ramgram</option>\
//         <option value='Siddharthanagar'>Siddharthanagar</option>\
//         <option value='Sandhikharka'>Sandhikharka</option>\
//         <option value='Tamghas'>Tamghas</option>\
//         <option value='Tansen' >Tansen</option>\
//         <option value='Ghorahi'>Ghorahi</option>\
//         <option value='Pyuthan'>Pyuthan</option>\
//        <option value='Liwang'>Liwang	</option>\
//        <option value='Rukumkot'>Rukumkot	</option>\
//        <option value='Nepalganj'>Nepalganj	</option>\
//        <option value='Gulariya'>Gulariya	</option>\
// 	   </select>";
       

			
// 		}
		
		
// 			else if(typevalue == 'Birendranagar')
// 		{
// 	   document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option>\
// 		<option value='Musikot'>Musikot</option>\
//         <option value='Salyan'>Salyan</option>\
//         <option value='Dunai'>Dunai</option>\
//         <option value='Simikot'>Simikot</option>\
//         <option value='Chandannath'>Chandannath</option>\
//         <option value='Manma' >Manma</option>\
//         <option value='Gamgadhi'>Gamgadhi</option>\
//        <option value='Narayan'>Narayan	</option>\
//        <option value='Khalanga'>Khalanga	</option>\
//        <option value='Nepalganj'>Nepalganj	</option>\
//        <option value='Gulariya'>Gulariya	</option>\
// 	   </select>";
       

			
// 		}
		
// 			else if(typevalue == 'Godawari')
// 		{
// 	   document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option>\
// 		<option value='Dhangadhi'>Dhangadhi</option>\
//         <option value='Dipayal Silgadhi'>Mangalsen</option>\
//         <option value='Dunai'>Dipayal Silgadhi</option>\
//         <option value='Jayaprithvi'>Jayaprithvi</option>\
//         <option value='Jayaprithvi'>Jayaprithvi</option>\
//         <option value='Martadi' >Martadi</option>\
//         <option value='Bhimdatta'>Bhimdatta</option>\
//         <option value='Amargadhi'>Amargadhi</option>\
//        <option value='Dasharathchand'>Dasharathchand	</option>\
//        <option value='Darchula'>Darchula	</option>\
// 	   </select>";


			
// 		}
		
		
// 			else if(typevalue == 'Barisal')
// 		{
// 	   document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option>\
// 		<option value='Barguna'>Barguna</option>\
//         <option value='Barisal'>Barisal</option>\
//         <option value='Bhola'>Bhola</option>\
//         <option value='Jhalokati'>Jhalokati</option>\
//         <option value='Patuakhali'>Patuakhali</option>\
//         <option value='Pirojpur'>Pirojpur</option>\
//       </select>";


			
// 		}
		
// 					else if(typevalue == 'Barisal')
// 		{
// 	   document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option>\
// 		<option value='Barguna'>Barguna</option>\
//         <option value='Bhola'>Bhola</option>\
//         <option value='Jhalokati'>Jhalokati</option>\
//         <option value='Patuakhali'>Patuakhali</option>\
//         <option value='Pirojpur'>Pirojpur</option>\
// 		</select>";
      


			
// 		}
		
// 		else if(typevalue == 'Chittagong')
// 		{
// 	   document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option>\
// 		<option value='Bandarban'>Bandarban</option>\
//         <option value='Brahmanbaria'>Brahmanbaria</option>\
//         <option value='Chandpur'>Chandpur</option>\
//         <option value='Comilla'>Comilla</option>\
//         <option value='Coxs Bazar'>Coxs Bazar</option>\
//            <option value='Feni'>Feni</option>\
//        <option value='Khagrachhari'>Khagrachhari</option>\
//        <option value='Lakshmipur'>Lakshmipur</option>\
//        <option value='Noakhali'>Noakhali</option>\
//        <option value='Rangamati'>Rangamati</option>\
// 	   </select>";
      


			
// 		}
		
// 		else if(typevalue == 'Dhaka')
// 		{
// 	   document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option>\
// 		<option value='Faridpur'>Faridpur</option>\
//         <option value='Gazipur'>Gazipur</option>\
//        <option value='Kishoreganj'>Kishoreganj</option>\
//         <option value='Madaripur'>Madaripur</option>\
//         <option value='Manikganj'>Manikganj</option>\
//            <option value='Munshiganj'>Munshiganj</option>\
//        <option value='Narayanganj'>Narayanganj</option>\
//        <option value='Narsingdi'>Narsingdi</option>\
//        <option value='Shariatpur'>Shariatpur</option>\
//        <option value='Tangail'>Tangail</option>\
//       </select>";


			
// 		}
		
		
// 		else if(typevalue == 'Khulna')
// 		{
// 	   document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option>\
// 		<option value='Bagerhat'>Bagerhat</option>\
//         <option value='Chuadanga'>Chuadanga</option>\
//         <option value='Jessore'>Jessore</option>\
//         <option value='Jhenaidah'>Jhenaidah</option>\
//         <option value='Madaripur'>Madaripur</option>\
//         <option value='Kushtia'>Kushtia</option>\
//        <option value='Magura'>Magura</option>\
//        <option value='Meherpur'>Meherpur</option>\
//        <option value='Narail'>Narail</option>\
//        <option value='Satkhira'>Satkhira</option>\
// </select>";


			
// 		}
		
// 		else if(typevalue == 'Mymensingh')
// 		{
// 	   document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option>\
// 		<option value='Jamalpur'>Jamalpur</option>\
//        <option value='Netrokona'>Netrokona</option>\
//         <option value='Sherpur'>Sherpur</option>\
//      </select>";


			
// 		}
		
		
// 		else if(typevalue == 'Rajshahi')
// 		{
// 	   document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option>\
// 		<option value='Bogra'>Bogra</option>\
//         <option value='Chapainawabganj'>Chapainawabganj</option>\
//         <option value='Joypurhat'>Joypurhat</option>\
//         <option value='Naogaon'>Naogaon</option>\
//         <option value='Natore'>Natore</option>\
//         <option value='Pabna'>Pabna</option>\
//        <option value='Sirajganj'>Sirajganj</option>\
//         <option value='Dinajpur'>Dinajpur</option>\
//         <option value='Gaibandha'>Gaibandha</option>\
//         <option value='Kurigram'>Kurigram</option>\
//         <option value='Lalmonirhat'>Lalmonirhat</option>\
//         <option value='Nilphamari'>Nilphamari</option>\
//         <option value='Panchagarh'>Panchagarh</option>\
//         <option value='Rangpur'>Rangpur</option>\
//         <option value='Thakurgaon'>Thakurgaon</option>\
//      </select>";


			
// 		}
		
		
// 		else if(typevalue == 'Sylhet')
// 		{
// 	   document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option>\
// 		<option value='Habiganj'>Habiganj</option>\
//         <option value='Moulvibazar'>Moulvibazar</option>\
//         <option value='Sunamganj'>Sunamganj</option>\
//       </select>";
			
// 		}
		
// 		else if(typevalue == 'Chandigarh')
// 		{
// 	   document.getElementById("citypid").innerHTML="<select name='city' id='cityid' class='input validate[required]'><option value='' selected='selected'>Select</option>\
// 		<option value='Chandigarh'>Chandigarh</option>\
//       </select>";
			
// 		}
		
		
		
		
// 	}